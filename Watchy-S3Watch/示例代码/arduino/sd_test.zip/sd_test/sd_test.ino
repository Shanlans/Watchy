#include "FS.h"
#include "SD_MMC.h"

void setup() {
  pinMode(40, OUTPUT);
  digitalWrite(40, LOW);
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n[ESP32-S3 SDMMC 1-bit Test]");

  // ⚙️ 指定 ESP32-S3 的 SDMMC 引脚
  // SD_MMC.setPins(47, 38, 48); // CLK, CMD, D0
  SD_MMC.setPins(4, 3, 5); // CLK, CMD, D0

  // ⚙️ 初始化 1-bit 模式
  if (!SD_MMC.begin("/sdcard", true)) {
    Serial.println("❌ SD_MMC initialization failed!");
    return;
  }

  Serial.println("✅ SD_MMC initialized successfully.");
  uint64_t cardSize = SD_MMC.cardSize() / (1024 * 1024);
  Serial.printf("Card Size: %llu MB\n", cardSize);

  File file = SD_MMC.open("/test.txt", FILE_WRITE);
  if (!file) {
    Serial.println("❌ Failed to open file for writing");
    return;
  }
  file.println("Hello from ESP32-S3 SDMMC 1-bit mode!");
  file.close();
  Serial.println("✅ Write test.txt OK.");

  file = SD_MMC.open("/test.txt");
  if (!file) {
    Serial.println("❌ Failed to open file for reading");
    return;
  }
  Serial.println("File content:");
  while (file.available()) {
    Serial.write(file.read());
  }
  file.close();
  Serial.println("\n✅ Read test.txt OK.");
}

void loop() {}
