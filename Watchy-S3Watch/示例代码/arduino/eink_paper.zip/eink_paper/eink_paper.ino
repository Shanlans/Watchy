#include <GxEPD2_BW.h>
#include <SPI.h>

// // GDEH0154D67 (200x200) 使用GxEPD2库
GxEPD2_BW<GxEPD2_154_T8, GxEPD2_154_T8::HEIGHT> display(GxEPD2_154_T8(/*CS=*/33, /*DC=*/34, /*RST=*/35, /*BUSY=*/36));

void setup() {
  Serial.begin(115200);
  Serial.println("GDEH0154D67 Library Version");

  SPI.begin(47, -1, 48, 33);
  
  // 降低SPI频率以提高稳定性
  display.epd2.selectSPI(SPI, SPISettings(100000, MSBFIRST, SPI_MODE0));
  
  // 初始化显示
  Serial.println("Initializing GDEH0154D67 display...");
  display.init(115200, true, 40000, true);
  delay(1000);
  
  // 显示测试内容
  Serial.println("Displaying test pattern...");
  display.setRotation(0);
  display.setTextColor(GxEPD_BLACK);
  display.setFullWindow();
  
  display.firstPage();
  do {
    display.fillScreen(GxEPD_WHITE);
    display.setCursor(10, 60);
    display.setTextSize(2);
    display.println("Helo World!");
    display.setCursor(20, 90);
    display.setTextSize(1);
    display.println("GDEH0154D67");
    display.setCursor(20, 110);
    display.println("E-Paper Display");
  } while (display.nextPage());
  
  delay(5000);
  display.hibernate();
  Serial.println("Display test completed.");
}

void loop() {
  // 空循环
}
