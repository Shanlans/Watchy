#include <Arduino.h>
#include "es8311.h"
#include "driver/i2s.h"

// I2C pins
#define I2C_SDA 12
#define I2C_SCL 11

// I2S pins (for ESP32-S3)
#define I2S_BCLK 18
#define I2S_LRCLK 1
#define I2S_DOUT 2
#define I2S_MCLK 37

// Amplifier enable pin
#define PA_ENABLE 8

// Audio settings
#define SAMPLE_RATE 44100
#define BITS_PER_SAMPLE 16
#define CHANNELS 2
#define BUFFER_SIZE 1024

// Test tones
#define TONE_FREQ 440  // A4
#define TONE_DURATION 1000  // milliseconds

ES8311 es8311;

// Function to initialize I2S
void initI2S()
{
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = (i2s_bits_per_sample_t)BITS_PER_SAMPLE,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = BUFFER_SIZE,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };

  i2s_pin_config_t pin_config = {
    .mck_io_num = I2S_MCLK,
    .bck_io_num = I2S_BCLK,
    .ws_io_num = I2S_LRCLK,
    .data_out_num = I2S_DOUT,
    .data_in_num = I2S_PIN_NO_CHANGE
  };

  i2s_driver_install(I2S_NUM_0, &i2s_config, 0, NULL);
  i2s_set_pin(I2S_NUM_0, &pin_config);
  i2s_set_sample_rates(I2S_NUM_0, SAMPLE_RATE);
}

// Function to play a tone
void playTone(uint16_t frequency, uint32_t duration)
{
  uint32_t total_samples = (duration * SAMPLE_RATE) / 1000;
  int16_t* buffer = new int16_t[total_samples * CHANNELS];
  
  // Generate stereo sine wave
  for (uint32_t i = 0; i < total_samples; i++) {
    float t = (float)i / SAMPLE_RATE;
    float sine = sin(2 * PI * frequency * t);
    int16_t sample = (int16_t)(sine * 32767);
    // Left channel
    buffer[i * 2] = sample;
    // Right channel
    buffer[i * 2 + 1] = sample;
  }
  
  // Play the tone
  size_t bytes_written = 0;
  i2s_write(I2S_NUM_0, buffer, total_samples * CHANNELS * sizeof(int16_t), &bytes_written, portMAX_DELAY);
  
  delete[] buffer;
  
  Serial.printf("Playing tone: %d Hz for %d ms\n", frequency, duration);
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("Initializing ES8311...");
  
  // Initialize ES8311
  if (!es8311.begin(I2C_SDA, I2C_SCL)) {
    Serial.println("Failed to initialize ES8311");
    while (1) {
      delay(1000);
    }
  }
  
  Serial.println("ES8311 initialized successfully");
  
  // Set volume to 100%
  es8311.setVolume(100);
  
  // Set sample rate
  es8311.setSampleRate(SAMPLE_RATE);
  
  // Set bits per sample
  es8311.setBitsPerSample(BITS_PER_SAMPLE);
  
  // Set to playback mode
  es8311.setMode(true);
  
  // Initialize I2S
  Serial.println("Initializing I2S...");
  initI2S();
  Serial.println("I2S initialized successfully");
  
  // Enable amplifier
  pinMode(PA_ENABLE, OUTPUT);
  digitalWrite(PA_ENABLE, HIGH);
  
  Serial.println("Setup complete. Ready to play tones.");
}

void loop() {
  // Play test tone
  Serial.println("\nPlaying test tone...");
  playTone(TONE_FREQ, TONE_DURATION);
  
  // Wait before repeating
  Serial.println("Test complete. Waiting for next cycle...");
  delay(2000);
}