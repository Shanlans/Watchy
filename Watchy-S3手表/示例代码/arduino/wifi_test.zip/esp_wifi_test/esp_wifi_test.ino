#include <WiFi.h>  // 对于 ESP32-C3 也是用这个库

const char* ssid     = "Xiaomi_4D90";       // <-- 替换为你的WiFi名称
const char* password = "zry88zry88";   // <-- 替换为你的WiFi密码

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.printf("Connecting to %s\n", ssid);

  WiFi.mode(WIFI_STA);           // 设置为 Station 模式
  WiFi.begin(ssid, password);    // 开始连接

  int retry_count = 0;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    retry_count++;
    if (retry_count > 20) {  // 10秒超时
      Serial.println("\n[!] Failed to connect to WiFi.");
      return;
    }
  }

  Serial.println("\n[+] WiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  
// 打印信号强度
  int rssi = WiFi.RSSI();
  Serial.print("Signal strength (RSSI): ");
  Serial.print(rssi);
  Serial.println(" dBm");
}

void loop() {
  // 每 10 秒刷新一次信号强度
  int rssi = WiFi.RSSI();
  Serial.print("[Loop] Current RSSI: ");
  Serial.print(rssi);
  Serial.println(" dBm");

  delay(10000);
}
